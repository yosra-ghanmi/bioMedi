export const environment = {
  production: true,
  baseApi:'http://localhost:8080/tasks'

};
